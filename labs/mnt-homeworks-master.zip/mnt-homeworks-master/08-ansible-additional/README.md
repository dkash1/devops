# Дополнительные материалы к лекциям по Ansible

1. [Как работать с Windows](http://onreader.mdl.ru/MasteringAnsible.3ed/content/Ch03.html)